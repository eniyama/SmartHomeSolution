/**
 * @file    strcture.h
 * @brief   Protocol frame and payload structure definitions
 *
 * This header defines all protocol-related data structures used for
 * communication between devices. It includes frame headers, payload
 * formats for Provision, Command, and Configuration frames.
 *
 * All structures are packed to ensure exact byte-level alignment
 * during transmission.
 *
 * @author  Dev-Laptop2
 * @date    Dec 22, 2025
 */

#ifndef STRCTURE_H_
#define STRCTURE_H_

#include <stdint.h>

/* =========================== Frame Type Definitions =========================== */

/**
 * @brief Frame type identifiers
 */
typedef enum
{
    /** Provisioning frame */
    eFrame_Type_Provision = 0x01,

    /** Command frame */
    eFrame_Type_Command   = 0x03,

    /** Configuration frame */
    eFrame_Type_Config    = 0x05

} eFrameType_t;


/* =========================== Packing Control =========================== */

/**
 * @brief Enable 1-byte structure packing
 */
#pragma pack(push, 1)


/* =========================== Common Header =========================== */

/**
 * @brief Common frame header
 *
 * Present at the beginning of every frame.
 *
 * Total size: 4 bytes
 */
typedef struct
{
    /** Protocol version */
    uint8_t      version;

    /** Frame type (Provision / Command / Config) */
    eFrameType_t frame_type;

    /** Unique device identifier */
    uint8_t      device_id;

    /** Reserved for future use (set to 0x00) */
    uint8_t      reserved;

} frame_header_t;


/* =========================== Common Sub-Structures =========================== */

/**
 * @brief Command type structure
 *
 * Used in Command and Provision frames.
 */
typedef struct
{
    /** Command identifier */
    uint8_t command_type;

} command_type_t;


/**
 * @brief Interval timing configuration
 *
 * Represents periodic interval in milliseconds or seconds
 * depending on protocol definition.
 */
typedef struct
{
    /** Interval time value */
    uint32_t interval_time;

} interval_time_t;


/**
 * @brief Sensor threshold configuration
 *
 * Contains threshold values for temperature and humidity.
 */
typedef struct
{
    /** Temperature threshold */
    uint16_t temperature_threshold;

    /** Humidity threshold */
    uint16_t humidity_threshold;

} sensor_t;


/**
 * @brief Actuator control parameters
 *
 * Defines default or requested states for actuators.
 */
typedef struct
{
    /** Default fan speed */
    uint8_t fan_default_speed;

    /** Default AC temperature */
    uint8_t ac_default_temp;

    /** Drapes open/close state */
    uint8_t drapes_state;

    /** Air purifier ON/OFF state */
    uint8_t air_purifier_state;

} actuator_t;


/* =========================== Payload Structures =========================== */

/**
 * @brief Provision frame payload
 *
 * Used during initial device provisioning.
 *
 * Total payload size: 60 bytes
 */
typedef struct
{
    /** Frame header */
    frame_header_t   header;

    /** Command information */
    command_type_t   command;

    /** Reporting interval */
    interval_time_t  interval;

    /** Sensor threshold configuration */
    sensor_t         sensor;

    /** Actuator default configuration */
    actuator_t       actuator;

    /** Padding to maintain fixed payload size */
    uint8_t          padding[43];

} provision_t;


/**
 * @brief Command frame payload
 *
 * Used to control actuators.
 *
 * Total payload size: 60 bytes
 */
typedef struct
{
    /** Frame header */
    frame_header_t   header;

    /** Command type */
    command_type_t   command;

    /** Actuator command data */
    actuator_t       actuator;

    /** Padding to maintain fixed payload size */
    uint8_t          padding[51];

} command_t;


/**
 * @brief Configuration frame payload
 *
 * Used to configure intervals and sensor thresholds.
 *
 * Total payload size: 60 bytes
 */
typedef struct
{
    /** Frame header */
    frame_header_t   header;

    /** Interval configuration */
    interval_time_t  interval;

    /** Sensor threshold configuration */
    sensor_t         sensor;

    /** Padding to maintain fixed payload size */
    uint8_t          padding[48];

} config_t;


/* =========================== Packing Control =========================== */

/**
 * @brief Restore previous packing alignment
 */
#pragma pack(pop)

#endif /* STRCTURE_H_ */
