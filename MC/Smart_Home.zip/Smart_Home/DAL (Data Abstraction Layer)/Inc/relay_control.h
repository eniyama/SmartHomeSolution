/**
 * @file    relay_control.h
 * @brief   Relay control interface definitions
 *
 * This header file declares APIs and command definitions
 * used to control an active-LOW relay module.
 *
 * The relay driver abstracts hardware polarity so higher
 * layers can use logical ON/OFF commands.
 *
 * @author  Dev-Laptop2
 * @date    Dec 27, 2025
 */

#ifndef RELAY_CONTROL_H_
#define RELAY_CONTROL_H_

#include "main.h"
#include "strcture.h"

/* ===================== Relay Command Definitions ===================== */

/**
 * @brief Command to turn relay ON (logical command)
 */
#define CMD_RELAY_ON   0x01

/**
 * @brief Command to turn relay OFF (logical command)
 */
#define CMD_RELAY_OFF  0x02


/* ===================== Relay API Prototypes ===================== */

/**
 * @brief Initializes the relay hardware
 *
 * Sets the relay to a default safe state during system startup.
 */
void Relay_Init(void);

/**
 * @brief Turns the relay ON
 *
 * For active-LOW relay:
 *  - GPIO LOW  -> Relay ON
 */
void Relay_ON(void);

/**
 * @brief Turns the relay OFF
 *
 * For active-LOW relay:
 *  - GPIO HIGH -> Relay OFF
 */
void Relay_OFF(void);

/**
 * @brief Processes relay-related command frame
 *
 * Decodes the received command and triggers
 * appropriate relay action.
 *
 * @param cmd Pointer to parsed command structure
 */
void Relay_ProcessCommand(const command_t *cmd);

#endif /* RELAY_CONTROL_H_ */
