/**
 * @file    dht11_driver.c
 * @brief   DHT11 temperature and humidity sensor driver for STM32
 *
 * This file provides APIs to initialize and read data from the DHT11 sensor
 * using GPIO and a microsecond timer.
 *
 * @author  Dev-Laptop2
 * @date    Dec 26, 2025
 */

#include "dht11_driver.h"
#include <string.h>

/* ===================== Private Variables ===================== */

/**
 * @brief GPIO port used for DHT11 communication
 */
static GPIO_TypeDef *dht_gpio_port;

/**
 * @brief GPIO pin used for DHT11 communication
 */
static uint16_t dht_gpio_pin;

/**
 * @brief Timer handle used for microsecond delay
 */
static TIM_HandleTypeDef *dht_tim;


/* ===================== Private Functions ===================== */

/**
 * @brief Generates a blocking delay in microseconds
 *
 * Uses hardware timer counter to generate precise microsecond delay.
 *
 * @param us Duration of delay in microseconds
 */
static void delay_us(uint16_t us)
{
    __HAL_TIM_SET_COUNTER(dht_tim, 0);
    while (__HAL_TIM_GET_COUNTER(dht_tim) < us);
}

/**
 * @brief Checks whether timeout duration has been exceeded
 *
 * Used to avoid infinite loops while waiting for sensor response.
 *
 * @param timeout_duration Timeout value in microseconds
 * @return true  If timeout exceeded
 * @return false Otherwise
 */
static bool check_timeout(uint16_t timeout_duration)
{
    return (__HAL_TIM_GET_COUNTER(dht_tim) > timeout_duration);
}

/**
 * @brief Configures GPIO pin mode as input or output
 *
 * @param pin_mode String specifying pin mode ("OUTPUT" or "INPUT")
 */
static void set_gpio_pin_mode(const char *pin_mode)
{
    GPIO_InitTypeDef GPIO_Struct;

    if (strcmp(pin_mode, "OUTPUT") == 0) {
        GPIO_Struct.Mode = GPIO_MODE_OUTPUT_PP;
    } else if (strcmp(pin_mode, "INPUT") == 0) {
        GPIO_Struct.Mode = GPIO_MODE_INPUT;
    } else {
        return;
    }

    GPIO_Struct.Pin   = dht_gpio_pin;
    GPIO_Struct.Pull  = GPIO_NOPULL;
    GPIO_Struct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;

    HAL_GPIO_Init(dht_gpio_port, &GPIO_Struct);
}


/* ===================== Public API Functions ===================== */

/**
 * @brief Initializes DHT11 driver
 *
 * Assigns GPIO port, pin, and timer for DHT11 communication
 * and starts the timer.
 *
 * @param gpio_port GPIO port (e.g., GPIOA, GPIOB)
 * @param gpio_pin  GPIO pin (e.g., GPIO_PIN_1)
 * @param tim       Timer handle (e.g., &htim6)
 */
void dht11_init(GPIO_TypeDef *gpio_port, uint16_t gpio_pin, TIM_HandleTypeDef *tim)
{
    dht_gpio_port = gpio_port;
    dht_gpio_pin  = gpio_pin;
    dht_tim       = tim;

    HAL_TIM_Base_Start(tim);
}

/**
 * @brief Reads temperature and humidity data from DHT11 sensor
 *
 * Executes start signal sequence, receives 40-bit response,
 * parses humidity and temperature values.
 *
 * @return dht11_data Structure containing temperature, humidity,
 *         and error status
 */
dht11_data dht11_data_read(void)
{
    uint8_t data[40] = {0};
    dht11_data results = {0};
    results.error = false;

    /* ================= Initialization Sequence ================= */

    set_gpio_pin_mode("OUTPUT");

    HAL_GPIO_WritePin(dht_gpio_port, dht_gpio_pin, GPIO_PIN_RESET);
    HAL_Delay(20);

    HAL_GPIO_WritePin(dht_gpio_port, dht_gpio_pin, GPIO_PIN_SET);
    set_gpio_pin_mode("INPUT");

    __HAL_TIM_SET_COUNTER(dht_tim, 0);
    while (HAL_GPIO_ReadPin(dht_gpio_port, dht_gpio_pin) == GPIO_PIN_SET) {
        if (check_timeout(200)) {
            results.error = true;
            return results;
        }
    }

    __HAL_TIM_SET_COUNTER(dht_tim, 0);
    while (HAL_GPIO_ReadPin(dht_gpio_port, dht_gpio_pin) == GPIO_PIN_RESET) {
        if (check_timeout(200)) {
            results.error = true;
            return results;
        }
    }

    __HAL_TIM_SET_COUNTER(dht_tim, 0);
    while (HAL_GPIO_ReadPin(dht_gpio_port, dht_gpio_pin) == GPIO_PIN_SET) {
        if (check_timeout(200)) {
            results.error = true;
            return results;
        }
    }

    /* ================= Read 40-bit Data ================= */

    for (uint8_t i = 0; i < 40; i++) {
        __HAL_TIM_SET_COUNTER(dht_tim, 0);
        while (HAL_GPIO_ReadPin(dht_gpio_port, dht_gpio_pin) == GPIO_PIN_RESET) {
            if (check_timeout(200)) {
                results.error = true;
                return results;
            }
        }

        delay_us(40);
        data[i] = (HAL_GPIO_ReadPin(dht_gpio_port, dht_gpio_pin) == GPIO_PIN_SET);

        __HAL_TIM_SET_COUNTER(dht_tim, 0);
        while (HAL_GPIO_ReadPin(dht_gpio_port, dht_gpio_pin) == GPIO_PIN_SET) {
            if (check_timeout(200)) {
                results.error = true;
                return results;
            }
        }
    }

    uint8_t humidity_int = 0, humidity_dec = 0;
    uint8_t temperature_int = 0, temperature_dec = 0;

    for (uint8_t i = 0; i < 8; i++)
        humidity_int = (humidity_int << 1) | data[i];

    for (uint8_t i = 8; i < 16; i++)
        humidity_dec = (humidity_dec << 1) | data[i];

    for (uint8_t i = 16; i < 24; i++)
        temperature_int = (temperature_int << 1) | data[i];

    for (uint8_t i = 24; i < 32; i++)
        temperature_dec = (temperature_dec << 1) | data[i];

    results.temperature = temperature_int;
    results.humidity    = humidity_int;

    /* Sanity check */
    if (results.temperature > 80 || results.humidity > 100) {
        results.error = true;
        results.temperature = 0;
        results.humidity = 0;
    }

    return results;
}
