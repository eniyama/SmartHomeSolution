#include "FaceRecognition.h"
#include <QDebug>
#include <QProcess>
#include <QTimer>
#include <QDir>
#include <QFile>
#include <QFileInfoList>
//#include <QDateTime>

// ------------------------------------------------------------
// Constructor
// ------------------------------------------------------------
FaceRecognition::FaceRecognition(QObject *parent)
    : QObject(parent), modelsLoaded(false), frameCounter(0)
{
    qDebug() << "FaceRecognition backend created for camera";

    // 🔥 CLEAR OLD FRAMES ON EVERY START
    clearAutoFramesFolder();

    // --- Start Python face capture script (if you still need it) ---
    QProcess *captureProcess = new QProcess(this);
    captureProcess->start(
        "python3",
        QStringList() << "/home/umadevi/webcam_capture/face_capture.py"
        );

    if (!captureProcess->waitForStarted()) {
        qDebug() << "Failed to start face_capture.py";
    } else {
        qDebug() << "face_capture.py started successfully";
    }

    // --- Start recognition timer ---
    startRecognitionTimer();
}

// ------------------------------------------------------------
// CLEAR auto_frames folder + reset counters
// ------------------------------------------------------------
void FaceRecognition::clearAutoFramesFolder()
{
    QString folderPath = QDir::homePath() + "/webcam_capture/auto_frames";
    QDir dir(folderPath);

    if (!dir.exists()) {
        dir.mkpath(".");
        return;
    }

    QFileInfoList files = dir.entryInfoList(QStringList() << "*.jpg", QDir::Files);
    for (const QFileInfo &file : files) {
        QFile::remove(file.absoluteFilePath());
    }

    processedFrames.clear();
    frameCounter = 0;

    qDebug() << "auto_frames cleared, counter reset";
}

// ------------------------------------------------------------
// CALLED FROM QML (live camera frame)
// ------------------------------------------------------------
void FaceRecognition::processFrame(const QImage &frame)
{
    if (frame.isNull())
        return;

    QString outputDir = QDir::homePath() + "/webcam_capture/auto_frames";
    QDir().mkpath(outputDir);

    QString filename = QString("%1/frame_%2.jpg")
                           .arg(outputDir)
                           .arg(frameCounter, 6, 10, QChar('0')); // 000000, 000001...

    if (frame.save(filename, "JPG")) {
        qDebug() << "Frame saved:" << filename;
        frameCounter++;
    } else {
        qDebug() << "[ERROR] Failed to save frame";
    }
}

// ------------------------------------------------------------
// TIMER: pick next unprocessed frame
// ------------------------------------------------------------
void FaceRecognition::startRecognitionTimer()
{
    QTimer *timer = new QTimer(this);

    connect(timer, &QTimer::timeout, this, [=]() {

        QString folderPath = QDir::homePath() + "/webcam_capture/auto_frames";
        QDir dir(folderPath);

        QFileInfoList list = dir.entryInfoList(
            QStringList() << "*.jpg",
            QDir::Files,
            QDir::Name        // 🔥 SORTED ORDER
            );

        if (list.isEmpty()) {
            qDebug() << "No frames found in auto_frames folder yet";
            return;
        }

        QString nextFrame;
        for (const QFileInfo &fileInfo : list) {
            QString path = fileInfo.absoluteFilePath();
            if (!processedFrames.contains(path)) {
                nextFrame = path;
                break;
            }
        }

        if (nextFrame.isEmpty())
            return;

        qDebug() << "Next frame to process:" << nextFrame;

        recognizeFace(nextFrame);
        processedFrames.insert(nextFrame);
    });

    timer->start(500); // every 2 seconds
}

// ------------------------------------------------------------
// PYTHON FACE RECOGNITION
// ------------------------------------------------------------
void FaceRecognition::recognizeFace(const QString &imagePath)
{
    qDebug() << "Running face_recognition.py on:" << imagePath;

    QProcess process;
    process.start(
        "python3",
        QStringList() << "/home/umadevi/face_recognition.py" << imagePath
        );

    if (!process.waitForFinished(500)) {
        qDebug() << "[ERROR] Face recognition timed out!";
        return;
    }

    QString output = process.readAllStandardOutput().trimmed();
    qDebug() << "Recognition output:" << output;


    emit faceRecognized(output);
}
