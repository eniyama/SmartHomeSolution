#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>

#include "MqttManager.h"
#include "FaceRecognition.h"


#include <QCamera>
#include <QMediaCaptureSession>



int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    // MQTT
    MqttManager mqttManager;
    engine.rootContext()->setContextProperty("mqttManager", &mqttManager);

    // Face recognition backend
    FaceRecognition faceRec;
    engine.rootContext()->setContextProperty("faceRec", &faceRec);

    engine.load(QUrl(QStringLiteral("qrc:/SmartHome/qml/Main.qml")));
    mqttManager.connectToBroker();

    if (engine.rootObjects().isEmpty())
        return -1;

    return app.exec();
}
