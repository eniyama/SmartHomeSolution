#define QT_FEATURE_vkb_sensitive_debug -1

#define QT_FEATURE_cerence_sdk -1

#define QT_FEATURE_cerence_hwr -1

#define QT_FEATURE_cerence_hwr_alphabetic -1

#define QT_FEATURE_cerence_hwr_cjk -1

#define QT_FEATURE_cerence_xt9 -1

#define QT_FEATURE_system_hunspell -1

#define QT_FEATURE_3rdparty_hunspell -1

#define QT_FEATURE_hunspell -1

#define QT_FEATURE_openwnn 1

#define QT_FEATURE_myscript -1

#define QT_FEATURE_pinyin 1

#define QT_FEATURE_vkb_no_bundle_pinyin -1

#define QT_FEATURE_tcime 1

#define QT_FEATURE_vkb_no_bundle_tcime -1

#define QT_FEATURE_zhuyin 1

#define QT_FEATURE_cangjie 1

#define QT_FEATURE_hangul 1

#define QT_FEATURE_thai 1

#define QT_FEATURE_vkb_lang_ar_AR 1

#define QT_FEATURE_vkb_lang_bg_BG 1

#define QT_FEATURE_vkb_lang_cs_CZ 1

#define QT_FEATURE_vkb_lang_da_DK 1

#define QT_FEATURE_vkb_lang_de_DE 1

#define QT_FEATURE_vkb_lang_el_GR 1

#define QT_FEATURE_vkb_lang_en_GB 1

#define QT_FEATURE_vkb_lang_en_US 1

#define QT_FEATURE_vkb_lang_es_ES 1

#define QT_FEATURE_vkb_lang_es_MX 1

#define QT_FEATURE_vkb_lang_et_EE 1

#define QT_FEATURE_vkb_lang_fa_FA 1

#define QT_FEATURE_vkb_lang_fi_FI 1

#define QT_FEATURE_vkb_lang_fr_CA 1

#define QT_FEATURE_vkb_lang_fr_FR 1

#define QT_FEATURE_vkb_lang_he_IL 1

#define QT_FEATURE_vkb_lang_hi_IN 1

#define QT_FEATURE_vkb_lang_hr_HR 1

#define QT_FEATURE_vkb_lang_hu_HU 1

#define QT_FEATURE_vkb_lang_id_ID 1

#define QT_FEATURE_vkb_lang_it_IT 1

#define QT_FEATURE_vkb_lang_ja_JP 1

#define QT_FEATURE_vkb_lang_ko_KR 1

#define QT_FEATURE_vkb_lang_ms_MY 1

#define QT_FEATURE_vkb_lang_nb_NO 1

#define QT_FEATURE_vkb_lang_nl_NL 1

#define QT_FEATURE_vkb_lang_pl_PL 1

#define QT_FEATURE_vkb_lang_pt_BR 1

#define QT_FEATURE_vkb_lang_pt_PT 1

#define QT_FEATURE_vkb_lang_ro_RO 1

#define QT_FEATURE_vkb_lang_ru_RU 1

#define QT_FEATURE_vkb_lang_sk_SK 1

#define QT_FEATURE_vkb_lang_sl_SI 1

#define QT_FEATURE_vkb_lang_sq_AL 1

#define QT_FEATURE_vkb_lang_sr_SP 1

#define QT_FEATURE_vkb_lang_sv_SE 1

#define QT_FEATURE_vkb_lang_th_TH 1

#define QT_FEATURE_vkb_lang_tr_TR 1

#define QT_FEATURE_vkb_lang_uk_UA 1

#define QT_FEATURE_vkb_lang_vi_VN 1

#define QT_FEATURE_vkb_lang_zh_CN 1

#define QT_FEATURE_vkb_lang_zh_TW 1

#define QT_FEATURE_vkb_lang_zh_HK -1

