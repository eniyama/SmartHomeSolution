#define QT_FEATURE_vkb_record_trace_input -1

#define QT_FEATURE_vkb_arrow_keynavigation -1

#define QT_FEATURE_vkb_desktop 1

#define QT_FEATURE_vkb_layouts 1

#define QT_FEATURE_vkb_no_builtin_style -1

#define QT_FEATURE_vkb_retro_style -1

#define QT_FEATURE_vkb_default_style 1

#define QT_FEATURE_vkb_bundle_cerence -1

#define QT_FEATURE_vkb_bundle_cerence_hwr -1

#define QT_FEATURE_vkb_bundle_cerence_xt9 -1

#define QT_FEATURE_vkb_cerence_xt9_debug -1

#define QT_FEATURE_vkb_cerence_xt9_9key_layouts -1

#define QT_FEATURE_vkb_cerence_static -1

