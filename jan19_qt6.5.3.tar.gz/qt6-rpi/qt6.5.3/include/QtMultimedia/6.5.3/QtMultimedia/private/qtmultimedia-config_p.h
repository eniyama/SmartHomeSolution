#define QT_FEATURE_ffmpeg -1

#define QT_FEATURE_alsa -1

#define QT_FEATURE_avfoundation -1

#define QT_FEATURE_coreaudio -1

#define QT_FEATURE_videotoolbox -1

#define QT_FEATURE_evr -1

#define QT_FEATURE_gstreamer_1_0 -1

#define QT_FEATURE_gstreamer -1

#define QT_FEATURE_gstreamer_app -1

#define QT_FEATURE_gstreamer_photography -1

#define QT_FEATURE_gstreamer_gl -1

#define QT_FEATURE_gpu_vivante -1

#define QT_FEATURE_linux_v4l 1

#define QT_FEATURE_linux_dmabuf 1

#define QT_FEATURE_vaapi -1

#define QT_FEATURE_mmrenderer -1

#define QT_FEATURE_pulseaudio -1

#define QT_FEATURE_wmsdk -1

#define QT_FEATURE_opensles -1

#define QT_FEATURE_wasm -1

#define QT_FEATURE_wmf -1

#define QT_FEATURE_spatialaudio 1

#define QT_FEATURE_spatialaudio_quick3d 1

