#define QT_FEATURE_alsa -1

#define QT_FEATURE_avfoundation -1

#define QT_FEATURE_coreaudio -1

#define QT_FEATURE_videotoolbox -1

#define QT_FEATURE_evr -1

#define QT_FEATURE_mmrenderer -1

#define QT_FEATURE_pulseaudio -1

